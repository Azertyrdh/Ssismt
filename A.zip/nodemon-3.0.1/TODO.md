# TODO

A rough outline of things I'd like to do with nodemon after 13 years of supporting the software:

- Upgrade mocha (I tried Jest once, but it can't fork and monitor the outputs, which is how most of the tests run)
- Switch to prettier from jshint (and commit formatted code)
- Sweep code for unused or overly complicated code(!)
